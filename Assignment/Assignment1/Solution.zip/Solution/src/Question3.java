import java.util.Scanner;

/**
 * Created by Zhaozhe on 5/19/16.
 */
public class Question3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int number = scanner.nextInt();

        if (number < 10) {
            System.out.print("0");
        }

        if (number < 100) {
            System.out.print("0");
        }

        if (number < 1000) {
            System.out.print("0");
        }

        System.out.println(number);


    }
}
