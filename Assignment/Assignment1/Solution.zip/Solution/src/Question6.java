import java.util.Scanner;

/**
 * Created by Zhaozhe on 5/19/16.
 */
public class Question6 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int x1 = scanner.nextInt();
        int y1 = scanner.nextInt();
        int x2 = scanner.nextInt();
        int y2 = scanner.nextInt();

        int x = x1 - x2;
        int y = y1 - y2;

        if (x < 0){
            x = -x;
        }

        if (y < 0){
            y = -y;
        }

        System.out.print(x);
        System.out.print(" ");
        System.out.println(y);
    }
}
