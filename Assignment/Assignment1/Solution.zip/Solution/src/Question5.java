import java.util.Scanner;

/**
 * Created by Zhaozhe on 5/19/16.
 */
public class Question5 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int number;
        int largest;

        number = scanner.nextInt();
        largest = number;

        number = scanner.nextInt();
        if (number > largest) {
            largest = number;
        }

        number = scanner.nextInt();
        if (number > largest) {
            largest = number;
        }

        System.out.println(largest);
    }
}
