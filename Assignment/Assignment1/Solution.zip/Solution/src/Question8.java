import java.util.Scanner;

/**
 * Created by Zhaozhe on 5/19/16.
 */
public class Question8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int atk1 = scanner.nextInt();
        int def1 = scanner.nextInt();
        int dex1 = scanner.nextInt();
        int agl1 = scanner.nextInt();

        int atk2 = scanner.nextInt();
        int def2 = scanner.nextInt();
        int dex2 = scanner.nextInt();
        int agl2 = scanner.nextInt();

        double atk = atk1;
        double def = def2;
        double dex = dex1 * (Math.random() * 0.4 - 0.2 + 1.0);
        double agl = agl2 * (Math.random() * 0.4 - 0.2 + 1.0);

        double damage = atk - def;
        if (damage < 0){
            damage = 1;
        }

        if (dex > agl * 1.5) {
            damage *= 2;
        } else if (dex < agl * 0.5) {
            damage = 0;
        } else {
            damage *= Math.random() * 0.2 - 0.1 + 1.0;
        }

        int damageInt = (int)damage;
        if (damage - damageInt > 0) {
            damageInt +=1;
        }
    }
}
