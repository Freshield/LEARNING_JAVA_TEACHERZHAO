import java.util.Scanner;

/**
 * Created by Zhaozhe on 5/19/16.
 */
public class Question2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double number = scanner.nextDouble();

        number = number * 100;
        int integerPart = (int)number;
        double floatPart = number - (int)number;
        if (floatPart >= 0.5) {
            integerPart ++;
        }

        System.out.print(integerPart / 100);
        System.out.print(".");

        integerPart %= 100;
        if (integerPart < 10) {
            System.out.print("0");
        }
        System.out.println(integerPart);


    }
}
