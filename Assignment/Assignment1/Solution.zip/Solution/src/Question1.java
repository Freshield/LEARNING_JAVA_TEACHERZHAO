import java.util.Scanner;

/**
 * Created by Zhaozhe on 5/19/16.
 */
public class Question1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int number = scanner.nextInt();
        int unit;

        unit = number / 1000;
        number = number % 1000;
        System.out.println(unit);

        unit = number / 100;
        number = number % 100;
        System.out.println(unit);

        unit = number / 10;
        number = number % 10;
        System.out.println(unit);

        unit = number;
        System.out.println(unit);


    }
}
