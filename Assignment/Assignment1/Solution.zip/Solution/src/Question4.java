import java.util.Scanner;

/**
 * Created by Zhaozhe on 5/19/16.
 */
public class Question4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int number = scanner.nextInt();

        if (number < 3) {
            if (number < 1){
                System.out.println("-----");
            } else {
                if (number < 2) {
                    System.out.println(".----");
                } else {
                    System.out.println("..---");
                }
            }
        } else {
            if (number < 4){
                System.out.println("...--");
            } else {
                if (number < 5) {
                    System.out.println("....-");
                } else {
                    System.out.println(".....");
                }
            }
        }
    }
}
