import java.util.Scanner;

/**
 * Created by Zhaozhe on 5/19/16.
 */
public class Question7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        long amount = scanner.nextLong();

        if (amount < 60) {
            System.out.print(amount);
            System.out.println("秒");
        } else {
            amount /= 60;

            if (amount < 60) {
                System.out.print(amount);
                System.out.println("分");
            } else {
                amount /= 60;

                if (amount < 24) {
                    System.out.print(amount);
                    System.out.println("小时");
                } else {
                    amount /= 24;

                    if (amount < 30) {
                        System.out.print(amount);
                        System.out.println("天");
                    } else {
                        amount /= 30;
                        System.out.print(amount);
                        System.out.println("月");
                    }
                }
            }
        }
    }
}
