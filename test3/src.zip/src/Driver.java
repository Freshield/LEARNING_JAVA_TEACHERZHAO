/**
 * Created by FRESHIELD on 2016/6/3.
 */
public class Driver {
    public static void main(String[] args) {
        new LinkedListTest().run();
    }
}
