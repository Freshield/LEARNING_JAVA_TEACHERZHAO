package com.zhaozhepublic.five;

/**
 * Created by Zhaozhe on 5/31/16.
 */
public class Player {
    public String name;
    public char token;
    public int score;

//    public Player(){
//        name = "不知道";
//        System.out.println("Player()");
//    }

    public Player(String name){
        this.name = name;
        System.out.println("Player(String)");
    }

    public void sayHello(){
        int i;
        String name;
        System.out.println("Hello, " + this.name);
    }

    public void f(){
        int i;
    }
}
