package com.zhaozhepublic.online;

/**
 * Created by Zhaozhe on 5/31/16.
 */
public class Game {
    public void run(){
        Player player = new Player();
        player.atk = 1;
        player.setHp(300);

        int damage = 400;

        player.setHp(player.getHp() - damage);

    }
}
