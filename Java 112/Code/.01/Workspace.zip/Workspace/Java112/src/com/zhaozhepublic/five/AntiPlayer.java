package com.zhaozhepublic.five;

/**
 * Created by Zhaozhe on 5/31/16.
 */
public class AntiPlayer {
    public String name;
}
