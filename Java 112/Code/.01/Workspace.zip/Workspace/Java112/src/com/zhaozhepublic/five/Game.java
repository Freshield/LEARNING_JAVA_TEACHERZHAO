package com.zhaozhepublic.five;

/**
 * Created by Zhaozhe on 5/31/16.
 */
public class Game {
    public void run() {
        // version 1
        String player1Name = "XiaoMing";
        String player2Name = "XiaoHong";
        char player1Token = 'x';
        char player2Token = 'o';

        // version 2
        String[] playerNames = {"XiaoMing","XiaoHong"};
        char[] playerTokens = {'x', 'o'};

        // version 3
        Player player1 = new Player("XiaoMing");
        //  public Player Player(){
        //  }

        Player player2 = new Player("XiaoHong");
        player1.token = 'x';
        player2.token = 'o';

        System.out.println(player1.name);

        player1.sayHello();
        player2.sayHello();

    }
}
