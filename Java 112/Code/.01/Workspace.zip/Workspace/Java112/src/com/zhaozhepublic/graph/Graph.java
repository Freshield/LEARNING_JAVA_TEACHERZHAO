package com.zhaozhepublic.graph;

/**
 * Created by Zhaozhe on 5/31/16.
 */
public class Graph {
    public void run(){
        Point point = new Point();
        point.setX(2);
//        point.setY(3);

        point.trace();
        System.out.println(point.description());

        Circle circle = new Circle();
        Point origin = new Point(1, 1);
        circle.setOrigin(origin);
        circle.setRadius(3);

        Point target = new Point(2, 3);
        circle.hitTest(target);





    }
}
