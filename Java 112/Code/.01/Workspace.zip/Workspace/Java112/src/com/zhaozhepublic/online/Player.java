package com.zhaozhepublic.online;

/**
 * Created by Zhaozhe on 5/31/16.
 */
public class Player {
    public int atk;
    public int def;

    private int hp;

    public int getHp(){
        return hp;
    }

    public void setHp(int hp){
        if (hp < 0) {
            hp = 0;
        }
        this.hp = hp;
    }
}
