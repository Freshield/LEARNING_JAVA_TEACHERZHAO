package com.freshield.attack;

/**
 * Created by FRESHIELD on 2016/6/8.
 */
public class Driver {
    public static void main(String[] args) {
        new Game().run();
    }
}
