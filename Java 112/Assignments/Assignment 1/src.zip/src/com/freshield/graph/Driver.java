package com.freshield.graph;

/**
 * Created by FRESHIELD on 2016/5/31.
 */
public class Driver {
    public static void main(String[] args) {
        new Graph().run2();
    }
}
