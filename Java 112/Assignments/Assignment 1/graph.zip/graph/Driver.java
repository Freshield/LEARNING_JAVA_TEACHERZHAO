package com.zhaozhepublic.graph;

/**
 * Created by Zhaozhe on 5/31/16.
 */
public class Driver {
    public static void main(String[] args) {
        new Graph().run();
    }
}
