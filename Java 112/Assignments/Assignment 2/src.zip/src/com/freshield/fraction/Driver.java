package com.freshield.fraction;

/**
 * Created by FRESHIELD on 2016/6/2.
 */
public class Driver {
    public static void main(String[] args) {
        new Mathematics().run();
    }
}
